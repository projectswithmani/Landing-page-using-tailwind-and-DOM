// var a = document.querySelector("#btn")
//  var b = document.querySelector(".bulb")  
//  var flag = 0
//  a.addEventListener("click" ,function () {
//     if (flag == 0){
//         b.style.backgroundColor = ("yellow")
//         a.innerHTML=("Off")
//         console.log("clicked");
//         flag = 1
//     }
//     else{
        
//         b.style.backgroundColor = ("aliceblue")
//         a.innerHTML=("On")
//         console.log("Again clicked");
//         flag = 0
//     }

//     // alert("Great ")
    
//  })


var button = document.querySelector("#btn")
var colurr = document.querySelector("#right")
var flag = 0
button.addEventListener("click" ,function(){
    if (flag==0){
        button.innerHTML=("Explored!!")
        button.style.backgroundColor = ("Green")
        flag=1
    }
    else{
        button.innerHTML=("Explore")
        flag=0
        button.style.backgroundColor = ("blue")
    }
    
})
var c = 0
colurr.addEventListener("click",function(){
    if (c ==0){
        colurr.style.backgroundColor =("white")
        console.log("colurr")
        c=1
    }
    else{
        colurr.style.backgroundColor =("#4ADE80")
        c=0
       
    }
})
// 